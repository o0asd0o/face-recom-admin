// .makeStyles-colorpickerButton-2

import styled from "@emotion/styled";

export const ColorContainer = styled('div')`
`

export const BannerContainer = styled("div")`
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 20px;
    position: relative;
`