import React from "react";

export const Settings: React.FC = () => {
    return <div>
        settings
    </div>
};

export default Settings;