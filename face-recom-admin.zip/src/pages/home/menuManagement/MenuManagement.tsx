import React from "react";

export const MenuManagement: React.FC = () => {
    return <div>
        menu management
    </div>
};

export default MenuManagement;